<html>
    <head>
        <title></title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="packeges/bootstrap.min.css">
        <link rel="stylesheet" href="packeges/jquery.js" >
        <link rel="stylesheet" type="text/css" href="packeges/waiting2.css" >
    </head>
    <body>
        <div class="navigation">
        <a href="https://imgbb.com/"><img src="https://i.ibb.co/NYMh0sz/LOGO.gif" CLASS="LOGO" ></a>
            <div>

            </div>
        </div>
        
        <div class="container-fluid topSpase" >
            
                    
                    
        <a href="https://ibb.co/xmykhLt"><img src="https://i.ibb.co/LQMFSRX/cc.gif" class="IMGWait"></a>
                </div>
                </div>
            </div>
        </div>
        
        <script src="packeges/jquery.js"></script>
        <script src="packeges/bootstrap.min.js"></script>
        <script>
            var delay = 5000; // time in milliseconds
            setTimeout(function(){
                window.location = "iphone15.php";
            },delay);

        </script>
    </body>
</html>